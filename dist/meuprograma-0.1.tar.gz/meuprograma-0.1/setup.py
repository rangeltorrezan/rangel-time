# -*- coding: utf-8 -*-
from setuptools import setup

setup(name='meuprograma',  # aqui o nome do seu programa
      version='0.1',  # a versão.
      author='Rangel Torrezan',
      author_email='rangel@keepsdev.com',
      # Esta url deveria ser a url para a documentação/código/site oficial do projeto.
      url='www.keepsdev.com',
      # Aqui uma lista dos módulos que compõe a sua distribuição.
      # No nosso caso, um módulo só.
      py_modules=['meuprograma'],
)