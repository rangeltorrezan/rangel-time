import time

def devolve_a_hora():
    return time.time()